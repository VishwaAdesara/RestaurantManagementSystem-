import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

class MenuItem {
    private String name;
    private double price;

    public MenuItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    } 
}

class Order {
    private MenuItem menuItem;

    public Order(MenuItem menuItem) {
        this.menuItem = menuItem;
    } 

    public MenuItem getMenuItem() {
        return menuItem;
    }
}

class OrderTaker {
    private ArrayList<Order> orders;

    public OrderTaker() {
        this.orders = new ArrayList<>();
    }

    public void takeOrder(Order order) {
        orders.add(order);
    }

    public void orderReady(Order order) {
        System.out.println("Order ready:  " + order.getMenuItem().getName());
    }

    public ArrayList<Order> getOrders() {
        return orders;
    }
}

public class RestaurantFinal {
    public static void main(String[] args) throws IOException {
        ArrayList<String> customerNames = new ArrayList<>();
        ArrayList<Order> orders = new ArrayList<>();
        ArrayList<String> od=new ArrayList<>();

        OrderTaker orderTaker = new OrderTaker();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Welcome to our restaurant! May I have your name? ");
        String customerName = scanner.nextLine();
        customerNames.add(customerName);

        System.out.println("\nHello, " + customerName + "! What would you like to order? \n \nPlease check our menu");

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Pizza");
            System.out.println("2. Pasta");
            System.out.println("3. Cold Drink");
            System.out.println("4. Finish Ordering");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 4) {
                break;
            }

            MenuItem menuItem = null;

            switch (choice) {
                case 1:
                    menuItem = new MenuItem("Pizza", getPrice("Pizza"));
                    od.add("Pizza");
                    break;
                case 2:
                    menuItem = new MenuItem("Pasta", getPrice("Pasta"));
                    od.add("Pasta");
                    break;
                case 3:
                    menuItem = new MenuItem("Cold Drink", getPrice("Cold Drink"));
                    od.add("Cold Drink");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    continue;
            } 

            orders.add(new Order(menuItem));
            orderTaker.takeOrder(new Order(menuItem));

            System.out.println("Your order has been placed successfully!");
            orderTaker.orderReady(new Order(menuItem));

        }

        // It just Generates bill
        double totalBill = generateBill(orderTaker.getOrders());
        System.out.println("Your order items:");

          for(String od1:od)
        {
            System.out.println(od1);
        }
        System.out.println("Total bill for " + customerName + ": Rs " + totalBill);
        // Write total bill to file
        try (FileWriter writer = new FileWriter("bill.txt")) {
            writer.write("Total bill for " + customerName + od+": Rs " + totalBill);
        }
    }   

    private static double getPrice(String itemName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(itemName + " Prices:");
       
        switch (itemName) {
            case "Pizza":
                System.out.println("1. Small - Rs 250.00");
                System.out.println("2. Medium - Rs 350.00");
                System.out.println("3. Large - Rs 450.00");
                break;
            case "Pasta":
                System.out.println("1. Red Sauce - Rs 150.00");
                System.out.println("2. White Sauce - Rs 200.00");
                System.out.println("3. Spaghetti - Rs 300.00");
                break;
            case "Cold Drink":
                System.out.println("1. 7UP - Rs 30.00");
                System.out.println("2. Cold Coco - Rs 40.00");
                System.out.println("3. Fanta - Rs 30.00");
                break;
        }

        System.out.print("Enter choice (1/2/3): ");
        int sizeChoice = scanner.nextInt();
        scanner.nextLine(); 
        double totalprice;
        switch (itemName) {
            case "Pizza":
                switch (sizeChoice){
                    case 1:System.out.println("enter the quantity : ");
                           int qunt=scanner.nextInt();
                           totalprice=250*qunt;
                           break;   
                    case 2:System.out.println("enter the quantity : ");
                           int qunt1=scanner.nextInt();
                           totalprice=350*qunt1;
                           break;
                    case 3:System.out.println("enter the quantity : ");
                           int qunt2=scanner.nextInt();
                           totalprice=450*qunt2;
                           break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        totalprice = getPrice(itemName); 
                }
                break;
            case "Pasta":
                switch (sizeChoice) {
                    case 1:System.out.println("enter the quantity : ");
                           int qunt4=scanner.nextInt();
                           totalprice=150*qunt4;
                           break;
                    case 2:System.out.println("enter the quantity : ");
                        int q5=scanner.nextInt();
                        totalprice=200*q5;
                        break;
                    case 3: System.out.println("enter the quantity:");
                            int q1=scanner.nextInt();
                        totalprice=300*q1;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        totalprice = getPrice(itemName); 
                }
                break;
            case "Cold Drink":
                switch (sizeChoice) {
                    case 1:System.out.println("enter the quantity : ");
                           int qunt6=scanner.nextInt();
                           totalprice=30*qunt6;
                           break;
                    case 2:System.out.println("enter the quantity : ");
                           int qunt7=scanner.nextInt();
                           totalprice=40*qunt7;
                           break;
                    case 3:System.out.println("enter the quantity : ");
                           int qunt8=scanner.nextInt();
                           totalprice=30*qunt8;
                           break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        totalprice = getPrice(itemName); // Recursively call getPrice until a valid choice is made
                }
                break;
            default:
                totalprice = 0; 
        }
        return totalprice;
    }

    private static double generateBill(ArrayList<Order> orders) {
        double totalBill = 0;
        for (Order order : orders) {
            totalBill += order.getMenuItem().getPrice();
        }
        return totalBill;
    }
}
